# 31st File ERP

Simple accounting app — UPI capture, manual journal entries, auto-generated P&L, Balance Sheet & Trial Balance.

## Built From
- **Stitch designs**: `stitch_31st_file_erp_dashboard.zip`
- **Design tokens**: Stitch DESIGN.md (colors, fonts, spacing)
- **Font**: Plus Jakarta Sans + JetBrains Mono (exact Stitch spec)

## Stack
- **Next.js 14** (App Router — frontend + API in one)
- **Neon PostgreSQL** (free tier database)
- **Drizzle ORM** (type-safe queries)
- **Tailwind CSS** (Stitch design tokens)
- **PapaParse** (UPI CSV import — no API key)
- **UploadThing** (document attachments)

## Setup on Replit

### 1. Install packages
```bash
npm install
```

### 2. Set Secrets (Replit 🔒 tab)
```
DATABASE_URL    = postgresql://... (from neon.tech)
NEXTAUTH_SECRET = (run: openssl rand -base64 32)
NEXTAUTH_URL    = https://YOUR-REPL.repl.co
```

### 3. Create database + seed accounts
```bash
npm run db:push    # Creates all tables in Neon
npm run db:seed    # Seeds 30 default accounts
```

### 4. Run
```bash
npm run dev
```

## Screens (11 total)
| Screen | Path |
|--------|------|
| Login | `/login` |
| Dashboard | `/dashboard` |
| UPI Capture | `/upi-capture` |
| New Entry | `/journal-entry` |
| Transactions | `/transactions` |
| Chart of Accounts | `/accounts` |
| Trial Balance | `/trial-balance` |
| P&L Statement | `/pl-statement` |
| Balance Sheet | `/balance-sheet` |
| Notes to Accounts | `/notes` |
| Settings | `/settings` |

## UPI Import (no API key needed)
1. **CSV**: Export from Google Pay / PhonePe / BHIM / Paytm → drop file
2. **SMS**: Paste UPI SMS messages → auto-parsed
3. **Manual**: Enter UTR reference directly

## How financial statements work
Every journal entry writes to `entry_lines`. The reports API reads these in real-time:
- **Trial Balance** → sums DR/CR per account
- **P&L** → sums Income vs Expenses group accounts
- **Balance Sheet** → Assets vs Liabilities+Equity from TB

## Logos
All from 31st File brand:
- Sidebar: `https://lottie.host/7e9f0f76.../vgHf4GtXbQ.png`
- Login: `https://lottie.host/30ce7548.../7Qw5Z1Ef6B.png`
