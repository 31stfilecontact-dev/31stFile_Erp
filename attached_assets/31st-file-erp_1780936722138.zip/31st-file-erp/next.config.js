/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ["lottie.host", "utfs.io"],
  },
};
module.exports = nextConfig;
